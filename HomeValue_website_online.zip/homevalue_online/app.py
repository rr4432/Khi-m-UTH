from pathlib import Path
import sqlite3
from datetime import datetime
import numpy as np
import pandas as pd
import streamlit as st
import joblib

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "mo_hinh_gia_nha.pkl"
DB_PATH = Path(__import__("os").environ.get("HOMEVALUE_DB_PATH", str(BASE_DIR / "homevalue.db")))
FEATURES = ["Dien_Tich", "So_Phong_Ngu", "So_Phong_Tam", "Khoang_Cach_Trung_Tam"]

st.set_page_config(page_title="HomeValue | Dự đoán giá nhà", page_icon="🏡", layout="wide")

st.markdown("""
<style>
.stApp { background: #f4f7fb; }
.block-container { max-width: 1250px; padding-top: 1.5rem; padding-bottom: 3rem; }
.hero { padding: 2rem 2.2rem; border-radius: 22px; color: white; background: linear-gradient(115deg,#14263d,#24627a); margin-bottom: 1.2rem; }
.hero h1 { color:white; margin:0; font-size:2.25rem; }
.hero p { color:#e0edf5; margin:.45rem 0 0 0; }
div[data-testid="stMetric"] { background:white; border:1px solid #e5eaf1; padding:1rem; border-radius:15px; }
.panel { background:white; border:1px solid #e4eaf2; border-radius:17px; padding:1.15rem 1.3rem; margin-bottom:1rem; }
.note { color:#66768a; font-size:.88rem; }
</style>
<div class="hero">
<h1>🏡 HomeValue</h1>
<p>Ước tính giá nhà · Lưu lịch sử · Quản lý danh sách · Phân tích và so sánh</p>
</div>
""", unsafe_allow_html=True)

def connect_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH, check_same_thread=False)

def init_db():
    with connect_db() as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS properties (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            address TEXT DEFAULT '',
            area REAL NOT NULL,
            bedrooms INTEGER NOT NULL,
            bathrooms INTEGER NOT NULL,
            distance_km REAL NOT NULL,
            predicted_price REAL NOT NULL,
            price_unit TEXT NOT NULL DEFAULT 'Chưa xác định',
            created_at TEXT NOT NULL
        )
        """)
        con.execute("""
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            property_id INTEGER,
            name TEXT NOT NULL,
            area REAL NOT NULL,
            bedrooms INTEGER NOT NULL,
            bathrooms INTEGER NOT NULL,
            distance_km REAL NOT NULL,
            predicted_price REAL NOT NULL,
            price_unit TEXT NOT NULL DEFAULT 'Chưa xác định',
            created_at TEXT NOT NULL,
            FOREIGN KEY(property_id) REFERENCES properties(id)
        )
        """)

@st.cache_resource
def load_model():
    # Chỉ tải file .pkl do bạn tin cậy; pickle/joblib có thể thực thi mã khi mở.
    return joblib.load(MODEL_PATH)

def fetch_df(table):
    with connect_db() as con:
        return pd.read_sql_query(f"SELECT * FROM {table} ORDER BY id DESC", con)

def insert_prediction(name, area, bedrooms, bathrooms, distance, price, unit):
    now = datetime.now().isoformat(timespec="seconds")
    with connect_db() as con:
        cur = con.execute(
            """INSERT INTO predictions
            (name,area,bedrooms,bathrooms,distance_km,predicted_price,price_unit,created_at)
            VALUES (?,?,?,?,?,?,?,?)""",
            (name, area, bedrooms, bathrooms, distance, price, unit, now)
        )
        return cur.lastrowid

def save_property(name, address, area, bedrooms, bathrooms, distance, price, unit):
    now = datetime.now().isoformat(timespec="seconds")
    with connect_db() as con:
        cur = con.execute(
            """INSERT INTO properties
            (name,address,area,bedrooms,bathrooms,distance_km,predicted_price,price_unit,created_at)
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (name, address, area, bedrooms, bathrooms, distance, price, unit, now)
        )
        return cur.lastrowid

def delete_property(property_id):
    with connect_db() as con:
        con.execute("DELETE FROM properties WHERE id = ?", (int(property_id),))

def delete_prediction(prediction_id):
    with connect_db() as con:
        con.execute("DELETE FROM predictions WHERE id = ?", (int(prediction_id),))

if not MODEL_PATH.exists():
    st.error("Thiếu file mo_hinh_gia_nha.pkl. Hãy đặt file cùng thư mục với app.py.")
    st.stop()

try:
    model = load_model()
except Exception as e:
    st.error(f"Không tải được mô hình: {e}")
    st.info("Có thể do khác phiên bản Python/scikit-learn/NumPy so với môi trường đã tạo file .pkl.")
    st.stop()

init_db()

with st.sidebar:
    st.header("Cài đặt")
    st.caption("HomeValue sử dụng file mô hình .pkl đã cung cấp.")
    st.warning("Đơn vị giá và độ chính xác chưa thể xác minh nếu thiếu dữ liệu huấn luyện gốc.")
    price_unit = st.selectbox("Đơn vị giá hiển thị", ["Chưa xác định", "Đồng", "Triệu đồng", "Tỷ đồng"], index=0)
    st.caption("Chọn đơn vị chỉ đổi nhãn, không quy đổi giá trị mô hình.")

tabs = st.tabs(["✨ Dự đoán", "🏘️ Danh sách căn nhà", "📈 Phân tích & so sánh", "🕘 Lịch sử"])

with tabs[0]:
    form_col, result_col = st.columns([1, 1], gap="large")
    with form_col:
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Thông tin căn nhà")
        with st.form("predict_form", clear_on_submit=False):
            property_name = st.text_input("Tên căn nhà / mã tham chiếu", value="Căn nhà mới")
            address = st.text_input("Địa chỉ / khu vực (không bắt buộc)", value="")
            area = st.number_input("Diện tích (m²)", min_value=1.0, max_value=10000.0, value=80.0, step=5.0)
            bedrooms = st.number_input("Số phòng ngủ", min_value=0, max_value=50, value=2, step=1)
            bathrooms = st.number_input("Số phòng tắm", min_value=0, max_value=50, value=2, step=1)
            distance = st.number_input("Khoảng cách đến trung tâm (km)", min_value=0.0, max_value=500.0, value=5.0, step=0.5)
            save_to_list = st.checkbox("Lưu căn nhà vào danh sách", value=True)
            submitted = st.form_submit_button("Ước tính giá nhà", type="primary", use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)

    with result_col:
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.subheader("Kết quả dự đoán")
        if submitted:
            x = pd.DataFrame([{
                "Dien_Tich": float(area),
                "So_Phong_Ngu": int(bedrooms),
                "So_Phong_Tam": int(bathrooms),
                "Khoang_Cach_Trung_Tam": float(distance)
            }], columns=FEATURES)
            try:
                pred = float(np.asarray(model.predict(x)).reshape(-1)[0])
                if not np.isfinite(pred):
                    raise ValueError("Mô hình trả về kết quả không hợp lệ.")
                st.metric("Giá trị mô hình dự đoán", f"{pred:,.2f}", help="Đơn vị gốc chưa được xác minh.")
                st.caption(f"Đơn vị đang chọn: {price_unit}. Lựa chọn này chỉ là nhãn hiển thị.")
                pid = None
                if save_to_list:
                    pid = save_property(property_name.strip() or "Căn nhà chưa đặt tên", address, area, bedrooms, bathrooms, distance, pred, price_unit)
                insert_prediction(property_name.strip() or "Căn nhà chưa đặt tên", area, bedrooms, bathrooms, distance, pred, price_unit)
                st.success("Đã lưu dự đoán vào lịch sử." + (" Đã thêm căn nhà vào danh sách." if save_to_list else ""))
                st.session_state["last_prediction"] = {
                    "name": property_name, "address": address, "area": area,
                    "bedrooms": bedrooms, "bathrooms": bathrooms,
                    "distance": distance, "price": pred, "unit": price_unit
                }
            except Exception as e:
                st.error(f"Không thể tạo dự đoán: {e}")
        else:
            st.info("Điền thông tin bên trái rồi nhấn **Ước tính giá nhà**.")
            st.write("Kết quả sẽ hiển thị tại đây.")
        st.markdown('</div>', unsafe_allow_html=True)
        st.markdown('<div class="panel"><b>Đầu vào của mô hình</b><p class="note">Diện tích · Phòng ngủ · Phòng tắm · Khoảng cách đến trung tâm</p></div>', unsafe_allow_html=True)

with tabs[1]:
    st.subheader("Danh sách căn nhà đã lưu")
    properties = fetch_df("properties")
    if properties.empty:
        st.info("Chưa có căn nhà nào. Hãy tạo dự đoán và bật tùy chọn lưu căn nhà.")
    else:
        display = properties.rename(columns={
            "id":"ID", "name":"Tên căn nhà", "address":"Địa chỉ", "area":"Diện tích (m²)",
            "bedrooms":"Phòng ngủ", "bathrooms":"Phòng tắm", "distance_km":"Khoảng cách (km)",
            "predicted_price":"Giá dự đoán", "price_unit":"Đơn vị", "created_at":"Thời gian lưu"
        })
        st.dataframe(display, use_container_width=True, hide_index=True)
        st.download_button("Tải danh sách căn nhà (CSV)", properties.to_csv(index=False).encode("utf-8-sig"),
                           "homevalue_danh_sach_can_nha.csv", "text/csv")
        ids = properties["id"].tolist()
        chosen = st.selectbox("Chọn ID căn nhà để xóa", ids, format_func=lambda v: f"ID {v} — {properties.loc[properties.id == v, 'name'].iloc[0]}")
        if st.button("Xóa căn nhà đã chọn"):
            delete_property(chosen)
            st.rerun()

with tabs[2]:
    st.subheader("Phân tích và so sánh giá")
    props = fetch_df("properties")
    if props.empty:
        st.info("Cần lưu ít nhất một căn nhà để xem biểu đồ so sánh.")
    else:
        metric1, metric2, metric3 = st.columns(3)
        metric1.metric("Số căn nhà", f"{len(props)}")
        metric2.metric("Diện tích trung bình", f"{props.area.mean():,.1f} m²")
        metric3.metric("Giá dự đoán trung bình", f"{props.predicted_price.mean():,.2f}")
        chart_df = props.sort_values("created_at")
        chart_df["Nhãn"] = chart_df["name"].astype(str) + " (#" + chart_df["id"].astype(str) + ")"
        st.markdown("#### So sánh giá dự đoán")
        st.bar_chart(chart_df.set_index("Nhãn")["predicted_price"])
        st.markdown("#### Diện tích và giá dự đoán")
        st.scatter_chart(chart_df, x="area", y="predicted_price", color="price_unit", size="bedrooms")
        st.markdown("#### Thông tin các căn nhà")
        st.dataframe(chart_df[["id","name","address","area","bedrooms","bathrooms","distance_km","predicted_price","price_unit"]].rename(columns={
            "id":"ID","name":"Tên","address":"Địa chỉ","area":"Diện tích (m²)",
            "bedrooms":"Phòng ngủ","bathrooms":"Phòng tắm","distance_km":"Khoảng cách (km)",
            "predicted_price":"Giá dự đoán","price_unit":"Đơn vị"
        }), use_container_width=True, hide_index=True)

with tabs[3]:
    st.subheader("Lịch sử dự đoán")
    history = fetch_df("predictions")
    if history.empty:
        st.info("Chưa có lịch sử dự đoán.")
    else:
        st.dataframe(history.rename(columns={
            "id":"ID","property_id":"ID căn nhà","name":"Tên căn nhà","area":"Diện tích (m²)",
            "bedrooms":"Phòng ngủ","bathrooms":"Phòng tắm","distance_km":"Khoảng cách (km)",
            "predicted_price":"Giá dự đoán","price_unit":"Đơn vị","created_at":"Thời gian"
        }), use_container_width=True, hide_index=True)
        st.download_button("Tải lịch sử (CSV)", history.to_csv(index=False).encode("utf-8-sig"),
                           "homevalue_lich_su_du_doan.csv", "text/csv")
        if st.button("Xóa toàn bộ lịch sử dự đoán"):
            with connect_db() as con:
                con.execute("DELETE FROM predictions")
            st.rerun()

st.divider()
st.caption("HomeValue · Bản thử nghiệm. Kết quả phụ thuộc vào mô hình đã huấn luyện. Chưa xác minh đơn vị giá, dữ liệu gốc hoặc độ chính xác; không dùng làm căn cứ duy nhất cho giao dịch.")
