# HomeValue — website dự đoán giá nhà

## Chức năng
- Dùng mô hình `mo_hinh_gia_nha.pkl` hiện có.
- Dự đoán từ diện tích, số phòng ngủ, số phòng tắm, khoảng cách đến trung tâm.
- Lưu lịch sử dự đoán và danh sách căn nhà bằng SQLite.
- Biểu đồ so sánh giá và quan hệ diện tích/giá.
- Xuất danh sách và lịch sử thành CSV.

## Chạy thử trên máy
Cần Python 3.10–3.12. Trong thư mục dự án chạy:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Đưa lên Internet bằng Streamlit Community Cloud
1. Tạo tài khoản GitHub và tạo repository mới, ví dụ `homevalue`.
2. Đưa `app.py`, `requirements.txt`, `README.md` và `mo_hinh_gia_nha.pkl` lên repository.
3. Vào https://share.streamlit.io/ và đăng nhập bằng GitHub.
4. Chọn **Create app**, chọn repository, branch `main`, main file path `app.py`.
5. Nhấn **Deploy**. Khi build thành công, Streamlit sẽ cấp URL dạng `https://ten-app.streamlit.app`.

## Lưu ý về lưu dữ liệu khi triển khai
Bản hiện tại lưu SQLite vào ổ đĩa của ứng dụng. Trên môi trường cloud, dữ liệu trên ổ đĩa có thể không bền vững sau khi khởi động lại hoặc redeploy. Nếu cần lưu lâu dài cho người dùng thật, hãy chuyển SQLite sang cơ sở dữ liệu managed như Supabase/PostgreSQL và lưu thông tin kết nối trong phần Secrets của nền tảng. Không đưa mật khẩu hoặc khóa bí mật lên GitHub.

## Lưu ý về mô hình
File `.pkl`/joblib có thể thực thi mã khi tải, vì vậy chỉ dùng file tin cậy. Đơn vị giá và độ chính xác chưa thể xác minh khi thiếu dữ liệu huấn luyện gốc. Nếu Streamlit báo lỗi phiên bản scikit-learn/NumPy, cần xác định phiên bản đã dùng để tạo mô hình và ghim phiên bản tương thích trong `requirements.txt`.
